package com.hybird.calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {


    EditText nmbr1,nmbr2;
    Button add,sub,mult,div,reset;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        nmbr1=(EditText) findViewById(R.id.firstnmbr);
        nmbr2=(EditText) findViewById(R.id.secondnmbr);

        result=(TextView) findViewById(R.id.result);


        add=(Button) findViewById(R.id.addbtn);
        sub=(Button) findViewById(R.id.subbtn);
        mult=(Button) findViewById(R.id.multbtn);
        div=(Button) findViewById(R.id.divbtn);
        reset=(Button) findViewById(R.id.btnreset);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float first,sec,results;
                first=Float.valueOf(nmbr1.getText().toString());
                sec=Float.valueOf(nmbr2.getText().toString());
                results=first+sec;
                result.setText("The Result is : "+results);
                

            }
        });

        sub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                float first,sec,results;
                first=Float.valueOf(nmbr1.getText().toString());
                sec=Float.valueOf(nmbr2.getText().toString());
                results=first-sec;
                result.setText("The Result is : "+results);

            }
        });

        mult.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                float first,sec,results;
                first=Float.valueOf(nmbr1.getText().toString());
                sec=Float.valueOf(nmbr2.getText().toString());
                results=first*sec;
                result.setText("The Result is : "+results);
            }
        });

        div.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float first,sec,results;
                first=Float.valueOf(nmbr1.getText().toString());
                sec=Float.valueOf(nmbr2.getText().toString());
                results=first/sec;
                result.setText("The Result is : "+results);
            }
        });
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                nmbr1.setText("");
                nmbr2.setText("");
                result.setText("The Result is : ");
            }
        });


    }
}
